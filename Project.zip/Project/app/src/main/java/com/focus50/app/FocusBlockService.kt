package com.focus50.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/** Optional user-enabled service: redirects selected distracting apps to Home during a focus session. */
class FocusBlockService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val prefs = getSharedPreferences("focus50", MODE_PRIVATE)
        if (!prefs.getBoolean("focusActive", false)) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        val blocked = (prefs.getString("blocked", "") ?: "").split(",").map { it.trim() }.filter { it.isNotEmpty() }
        if (pkg in blocked) performGlobalAction(GLOBAL_ACTION_HOME)
    }
    override fun onInterrupt() = Unit
}
