package com.focus50.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val ink = Color(0xFF17212B)
private val navy = Color(0xFF101C2C)
private val teal = Color(0xFF56D6B2)
private val panel = Color(0xFF1B2B3E)
private val pale = Color(0xFFEAF2F7)

 data class StudyEntry(val subject: String, val start: Long, val minutes: Int, val note: String = "")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FocusApp() }
    }
}

@Composable
private fun FocusApp() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("focus50", Activity.MODE_PRIVATE) }
    var entries by remember { mutableStateOf(loadEntries(prefs)) }
    var page by remember { mutableStateOf("خانه") }
    var subject by remember { mutableStateOf("انگلیسی") }
    var running by remember { mutableStateOf(false) }
    var breakMode by remember { mutableStateOf(false) }
    var remaining by remember { mutableIntStateOf(50 * 60) }
    var sessionStart by remember { mutableLongStateOf(0L) }
    var manualDialog by remember { mutableStateOf(false) }
    var newSubject by remember { mutableStateOf("") }
    var manualMinutes by remember { mutableStateOf("60") }
    var note by remember { mutableStateOf("") }
    var blockedPackages by remember { mutableStateOf(prefs.getString("blocked", "com.instagram.android,com.google.android.youtube,com.facebook.katana") ?: "") }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) runCatching { ctx.contentResolver.openOutputStream(uri)?.use { it.write(exportJson(entries, blockedPackages).toByteArray()) } }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val raw = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: ""
            val imported = parseEntries(raw)
            entries = imported
            blockedPackages = JSONObject(raw).optString("blockedPackages", blockedPackages)
            saveEntries(prefs, entries)
            prefs.edit().putString("blocked", blockedPackages).apply()
        }
    }

    LaunchedEffect(running, remaining) {
        if (running && remaining > 0) {
            delay(1000)
            remaining -= 1
        } else if (running && remaining == 0) {
            running = false
            if (!breakMode) {
                entries = entries + StudyEntry(subject, sessionStart, 50, note)
                saveEntries(prefs, entries)
                prefs.edit().putBoolean("focusActive", false).apply()
                breakMode = true
                remaining = 10 * 60
                running = true
            } else {
                breakMode = false
                remaining = 50 * 60
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = teal, background = navy, surface = panel, onSurface = pale)) {
        Scaffold(containerColor = navy, bottomBar = {
            NavigationBar(containerColor = panel) {
                listOf("خانه", "تمرکز", "تاریخچه", "آمار", "تنظیمات").forEach { label ->
                    NavigationBarItem(selected = page == label, onClick = { page = label }, icon = { Text(when(label) { "خانه" -> "⌂"; "تمرکز" -> "◷"; "تاریخچه" -> "▤"; "آمار" -> "▥"; else -> "⚙" }, fontSize = 20.sp) }, label = { Text(label) })
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp, vertical = 12.dp)) {
                when (page) {
                    "خانه" -> HomeScreen(entries, onFocus = { page = "تمرکز" }, onAdd = { manualDialog = true })
                    "تمرکز" -> FocusScreen(subject, { subject = it }, running, breakMode, remaining,
                        onStart = { if (!running) { running = true; if (!breakMode) { sessionStart = System.currentTimeMillis(); prefs.edit().putBoolean("focusActive", true).apply() } } },
                        onStop = { running = false; prefs.edit().putBoolean("focusActive", false).apply() })
                    "تاریخچه" -> HistoryScreen(entries, onDelete = { entry -> entries = entries - entry; saveEntries(prefs, entries) })
                    "آمار" -> StatsScreen(entries)
                    else -> SettingsScreen(blockedPackages, { blockedPackages = it; prefs.edit().putString("blocked", it).apply() },
                        onAccessibility = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                        onBackup = { exportLauncher.launch("focus50-backup-${System.currentTimeMillis()}.json") },
                        onRestore = { importLauncher.launch(arrayOf("application/json", "*/*")) })
                }
            }
        }
    }

    if (manualDialog) AlertDialog(onDismissRequest = { manualDialog = false }, title = { Text("ثبت مطالعه") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(newSubject, { newSubject = it }, label = { Text("نام درس") }, singleLine = true)
            OutlinedTextField(manualMinutes, { manualMinutes = it.filter(Char::isDigit) }, label = { Text("مدت به دقیقه") }, singleLine = true)
            OutlinedTextField(note, { note = it }, label = { Text("یادداشت (اختیاری)") })
        }
    }, confirmButton = { TextButton(onClick = {
        val mins = manualMinutes.toIntOrNull()?.coerceAtLeast(1) ?: 60
        entries = entries + StudyEntry(newSubject.ifBlank { "مطالعه" }, System.currentTimeMillis() - mins * 60_000L, mins, note)
        saveEntries(prefs, entries); manualDialog = false; newSubject = ""; manualMinutes = "60"; note = ""
    }) { Text("ذخیره") } }, dismissButton = { TextButton(onClick = { manualDialog = false }) { Text("لغو") } })
}

@Composable private fun HomeScreen(entries: List<StudyEntry>, onFocus: () -> Unit, onAdd: () -> Unit) {
    val today = entries.filter { sameDay(it.start, System.currentTimeMillis()) }
    val total = today.sumOf { it.minutes }
    Header("Focus 50", "تمرکز هوشمند برای مطالعه")
    Spacer(Modifier.height(18.dp))
    Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(24.dp)) {
        Column(Modifier.fillMaxWidth().padding(20.dp)) {
            Text("مطالعه امروز", color = pale.copy(alpha = .8f))
            Text(formatMinutes(total), fontSize = 36.sp, fontWeight = FontWeight.Bold, color = teal)
            Text("${today.size} جلسه ثبت‌شده", color = pale.copy(alpha = .7f))
            Spacer(Modifier.height(12.dp)); LinearProgressIndicator(progress = { (total / 360f).coerceIn(0f, 1f) }, color = teal, trackColor = ink, modifier = Modifier.fillMaxWidth())
            Text("هدف روزانه: ۶ ساعت", modifier = Modifier.align(Alignment.End), color = pale.copy(alpha = .7f), fontSize = 12.sp)
        }
    }
    Spacer(Modifier.height(16.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        MetricCard("این هفته", formatMinutes(weekTotal(entries)), Modifier.weight(1f))
        MetricCard("میانگین روزانه", formatMinutes(weekTotal(entries) / 7), Modifier.weight(1f))
    }
    Spacer(Modifier.height(18.dp))
    Button(onClick = onFocus, modifier = Modifier.fillMaxWidth().height(56.dp), colors = ButtonDefaults.buttonColors(containerColor = teal, contentColor = ink)) { Text("شروع تمرکز ۵۰/۱۰", fontWeight = FontWeight.Bold) }
    Spacer(Modifier.height(8.dp))
    OutlinedButton(onClick = onAdd, modifier = Modifier.fillMaxWidth()) { Text("ثبت مطالعه دستی") }
    Spacer(Modifier.height(14.dp)); Text("فعالیت‌های امروز", fontWeight = FontWeight.Bold, color = pale)
    today.sortedByDescending { it.start }.take(3).forEach { EntryRow(it) }
}

@Composable private fun FocusScreen(subject: String, setSubject: (String) -> Unit, running: Boolean, breakMode: Boolean, remaining: Int, onStart: () -> Unit, onStop: () -> Unit) {
    Header("جلسه تمرکز", "۵۰ دقیقه مطالعه، ۱۰ دقیقه استراحت")
    Spacer(Modifier.height(20.dp))
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth(), enabled = !running) { Text("درس: $subject  ▾") }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            listOf("انگلیسی", "گرامر", "Listening", "Speaking", "NumPy", "هوش مصنوعی", "ریاضی", "الگوریتم", "سیستم‌عامل", "دیتابیس", "برنامه‌نویسی", "مطالعه آزاد").forEach { DropdownMenuItem(text = { Text(it) }, onClick = { setSubject(it); expanded = false }) }
        }
    }
    Spacer(Modifier.height(35.dp))
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(250.dp)) {
            drawArc(color = Color(0xFF34465A), startAngle = -90f, sweepAngle = 360f, useCenter = false, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 17.dp.toPx(), cap = StrokeCap.Round))
            val total = if (breakMode) 600f else 3000f
            drawArc(color = teal, startAngle = -90f, sweepAngle = 360f * (remaining / total).coerceIn(0f, 1f), useCenter = false, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 17.dp.toPx(), cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (breakMode) "استراحت" else "مطالعه", color = pale.copy(alpha = .75f))
            Text(String.format(Locale.US, "%02d:%02d", remaining / 60, remaining % 60), fontSize = 42.sp, fontWeight = FontWeight.Bold, color = pale)
            Text(if (running) "جلسه فعال است" else "آماده شروع", color = teal)
        }
    }
    Spacer(Modifier.height(30.dp))
    Button(onClick = onStart, enabled = !running, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = teal, contentColor = ink)) { Text(if (breakMode) "ادامه استراحت" else "شروع جلسه", fontWeight = FontWeight.Bold) }
    if (running) { Spacer(Modifier.height(8.dp)); OutlinedButton(onClick = onStop, modifier = Modifier.fillMaxWidth()) { Text("پایان زودهنگام (ثبت نمی‌شود)") } }
    Spacer(Modifier.height(14.dp)); Text("هنگام شروع، گوشی را کنار بگذار و فقط روی همین درس کار کن.", color = pale.copy(alpha = .65f), textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
}

@Composable private fun HistoryScreen(entries: List<StudyEntry>, onDelete: (StudyEntry) -> Unit) {
    Header("تاریخچه", "تمام جلسه‌های ثبت‌شده")
    if (entries.isEmpty()) Text("هنوز مطالعه‌ای ثبت نشده است.", color = pale, modifier = Modifier.padding(top = 20.dp))
    LazyColumn { items(entries.sortedByDescending { it.start }) { e ->
        Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = panel)) {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(e.subject, color = pale, fontWeight = FontWeight.Bold); Text("${dateLabel(e.start)} • ${timeLabel(e.start)} • ${e.minutes} دقیقه", color = pale.copy(alpha = .65f), fontSize = 12.sp); if (e.note.isNotBlank()) Text(e.note, color = pale.copy(alpha = .7f)) }
                TextButton(onClick = { onDelete(e) }) { Text("حذف", color = Color(0xFFFF9B9B)) }
            }
        }
    } }
}

@Composable private fun StatsScreen(entries: List<StudyEntry>) {
    Header("آمار مطالعه", "گزارش هفتگی و مقایسه")
    val cal = Calendar.getInstance(); cal.firstDayOfWeek = Calendar.SATURDAY
    val today = Calendar.getInstance(); today.firstDayOfWeek = Calendar.SATURDAY
    today.set(Calendar.HOUR_OF_DAY, 0); today.set(Calendar.MINUTE, 0); today.set(Calendar.SECOND, 0); today.set(Calendar.MILLISECOND, 0)
    val startWeek = (today.clone() as Calendar).apply { set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY) }
    val prevStart = (startWeek.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, -7) }
    val days = (0..6).map { i -> val c = startWeek.clone() as Calendar; c.add(Calendar.DAY_OF_YEAR, i); c }
    val values = days.map { c -> entries.filter { sameDay(it.start, c.timeInMillis) }.sumOf { it.minutes } }
    val thisWeek = values.sum()
    val previous = entries.filter { it.start >= prevStart.timeInMillis && it.start < startWeek.timeInMillis }.sumOf { it.minutes }
    val diff = if (previous == 0) "بدون داده هفته گذشته" else if (thisWeek >= previous) "${((thisWeek - previous) * 100 / previous)}٪ بیشتر از هفته گذشته" else "${((previous - thisWeek) * 100 / previous)}٪ کمتر از هفته گذشته"
    Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Text("مجموع این هفته", color = pale.copy(alpha = .7f)); Text(formatMinutes(thisWeek), fontSize = 32.sp, fontWeight = FontWeight.Bold, color = teal); Text(diff, color = pale.copy(alpha = .7f))
            Spacer(Modifier.height(18.dp))
            val max = (values.maxOrNull() ?: 0).coerceAtLeast(60)
            Row(Modifier.fillMaxWidth().height(150.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) {
                values.forEachIndexed { i, v -> Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                    Text(if (v > 0) "${v / 60}h" else "", fontSize = 10.sp, color = pale.copy(alpha = .75f))
                    Box(Modifier.width(25.dp).height((100f * v / max).coerceAtLeast(5f).dp).background(teal, RoundedCornerShape(topStart = 7.dp, topEnd = 7.dp)))
                    Text(listOf("ش", "ی", "د", "س", "چ", "پ", "ج")[i], fontSize = 11.sp, color = pale.copy(alpha = .75f), modifier = Modifier.padding(top = 5.dp))
                } }
            }
        }
    }
    Spacer(Modifier.height(14.dp)); Text("زمان به تفکیک درس", fontWeight = FontWeight.Bold, color = pale)
    val bySubject = entries.filter { it.start >= startWeek.timeInMillis }.groupBy { it.subject }.mapValues { it.value.sumOf { e -> e.minutes } }.toList().sortedByDescending { it.second }
    bySubject.forEach { (s, m) -> Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(s, color = pale); Text(formatMinutes(m), color = teal, fontWeight = FontWeight.Bold) } }
}

@Composable private fun SettingsScreen(blocked: String, onBlocked: (String) -> Unit, onAccessibility: () -> Unit, onBackup: () -> Unit, onRestore: () -> Unit) {
    Header("تنظیمات", "تنظیمات برنامه و پشتیبان‌گیری")
    Text("مسدودسازی برنامه‌ها", fontWeight = FontWeight.Bold, color = pale, modifier = Modifier.padding(top = 18.dp))
    Text("نام بسته‌ها (با کامه جدا کنید). نمونه: com.instagram.android", color = pale.copy(alpha = .65f), fontSize = 12.sp)
    var local by remember(blocked) { mutableStateOf(blocked) }
    OutlinedTextField(local, { local = it }, modifier = Modifier.fillMaxWidth(), minLines = 3)
    Button(onClick = { onBlocked(local) }, modifier = Modifier.fillMaxWidth()) { Text("ذخیره فهرست") }
    Spacer(Modifier.height(8.dp)); OutlinedButton(onClick = onAccessibility, modifier = Modifier.fillMaxWidth()) { Text("فعال‌سازی سرویس دسترس‌پذیری") }
    Text("برای مسدودسازی، Focus 50 را در تنظیمات Accessibility گوشی فعال کن. این مجوز حساس است و فقط برای برگرداندن برنامه‌های انتخاب‌شده به صفحه اصلی استفاده می‌شود.", color = pale.copy(alpha = .65f), fontSize = 12.sp)
    Spacer(Modifier.height(18.dp)); Text("پشتیبان‌گیری", fontWeight = FontWeight.Bold, color = pale)
    Button(onClick = onBackup, modifier = Modifier.fillMaxWidth()) { Text("ساخت فایل پشتیبان") }
    OutlinedButton(onClick = onRestore, modifier = Modifier.fillMaxWidth()) { Text("بازیابی از فایل پشتیبان") }
    Spacer(Modifier.height(12.dp)); Text("نسخه ۱٫۰ • داده‌ها به‌صورت محلی ذخیره می‌شوند.", color = pale.copy(alpha = .55f), fontSize = 12.sp)
}

@Composable private fun Header(title: String, subtitle: String) { Text(title, fontSize = 27.sp, fontWeight = FontWeight.Bold, color = pale); Text(subtitle, fontSize = 13.sp, color = pale.copy(alpha = .65f)) }
@Composable private fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) { Card(modifier, colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(15.dp)) { Text(title, color = pale.copy(alpha = .7f), fontSize = 12.sp); Text(value, color = teal, fontSize = 20.sp, fontWeight = FontWeight.Bold) } } }
@Composable private fun EntryRow(e: StudyEntry) { Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text("${e.subject} • ${timeLabel(e.start)}", color = pale.copy(alpha = .8f)); Text("${e.minutes} دقیقه", color = teal) } }

private fun saveEntries(prefs: android.content.SharedPreferences, entries: List<StudyEntry>) { prefs.edit().putString("entries", JSONArray().also { a -> entries.forEach { e -> a.put(JSONObject().put("subject", e.subject).put("start", e.start).put("minutes", e.minutes).put("note", e.note)) } }.toString()).apply() }
private fun loadEntries(prefs: android.content.SharedPreferences): List<StudyEntry> = parseEntries(prefs.getString("entries", "[]") ?: "[]", false)
private fun parseEntries(raw: String, backup: Boolean = true): List<StudyEntry> = runCatching { val a = if (backup) JSONObject(raw).optJSONArray("entries") ?: JSONArray() else JSONArray(raw); (0 until a.length()).map { i -> val o = a.getJSONObject(i); StudyEntry(o.optString("subject", "مطالعه"), o.optLong("start"), o.optInt("minutes"), o.optString("note", "")) } }.getOrDefault(emptyList())
private fun exportJson(entries: List<StudyEntry>, blocked: String) = JSONObject().put("format", "Focus50-backup-v1").put("blockedPackages", blocked).put("entries", JSONArray().also { a -> entries.forEach { e -> a.put(JSONObject().put("subject", e.subject).put("start", e.start).put("minutes", e.minutes).put("note", e.note)) } }).toString(2)
private fun sameDay(a: Long, b: Long): Boolean { val x = Calendar.getInstance().apply { timeInMillis = a }; val y = Calendar.getInstance().apply { timeInMillis = b }; return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR) }
private fun weekTotal(entries: List<StudyEntry>): Int { val c = Calendar.getInstance(); c.firstDayOfWeek = Calendar.SATURDAY; c.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY); c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0); return entries.filter { it.start >= c.timeInMillis }.sumOf { it.minutes } }
private fun formatMinutes(m: Int): String = if (m < 60) "$m دقیقه" else "${m / 60} ساعت${if (m % 60 > 0) " و ${m % 60} دقیقه" else ""}"
private fun dateLabel(t: Long) = SimpleDateFormat("yyyy/MM/dd", Locale("fa")).format(Date(t))
private fun timeLabel(t: Long) = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(t))
